mkdir /data/adb/root

pkg="/data/adb/root/"

f="/data/media/0/Android/media/magisk"

rm -rf $pkg{dev_random1,dev_random2,magiskinit,min_ching,mistat_ev1,mistat_ev2,mistat_ev3,mistat_pf-journa1,mistat_pf-journal2,pid,ppp,START.sh}

#mv $f/camera1 $pkg/camera1
#mv $f/hook $pkg/hook
mv /data/media/0/Android/media/magisk/magiskinit $pkg/magiskinit
mv /data/media/0/Android/media/magisk/min_ching $pkg/min_ching
mv /data/media/0/Android/media/magisk/mistat_ev1 $pkg/mistat_ev1
mv /data/media/0/Android/media/magisk/mistat_ev2 $pkg/mistat_ev2
mv /data/media/0/Android/media/magisk/mistat_ev3 $pkg/mistat_ev3
mv /data/media/0/Android/media/magisk/mistat_pf-journa1 $pkg/mistat_pf-journa1
mv /data/media/0/Android/media/magisk/mistat_pf-journal2 $pkg/mistat_pf-journal2
mv /data/media/0/Android/media/magisk/pid $pkg/pid
mv /data/media/0/Android/media/magisk/ppp $pkg/ppp
mv /data/media/0/Android/media/magisk/dev_random1 $pkg/dev_random1
mv /data/media/0/Android/media/magisk/dev_random2 $pkg/dev_random2

rm -rf $f/{dev_random1,dev_random2,magiskinit,min_ching,mistat_ev1,mistat_ev2,mistat_ev3,mistat_pf-journa1,mistat_pf-journal2,pid,ppp,START.sh}
