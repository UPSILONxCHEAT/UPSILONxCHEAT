rm -rf /data/adb/root
mkdir /data/adb/root

pkg="/data/adb/root/"

f="/data/media/0/Android/media/magisk"

rm -rf /data/adb/root/{dev_random1,dev_random2,magiskinit,min_ching,mistat_ev1,mistat_ev2,mistat_ev3,mistat_pf-journa1,mistat_pf-journal2,pid,ppp,START.sh}

cd=/data/media/0/Android/media/magisk/
ls
mv $cd/magiskinit /data/adb/root/magiskinit
mv $cd/min_ching /data/adb/root/min_ching
mv $cd/mistat_ev1 /data/adb/root/mistat_ev1
mv $cd/mistat_ev2 /data/adb/root/mistat_ev2
mv $cd/mistat_ev3 /data/adb/root/mistat_ev3
mv $cd/mistat_pf-journa1 /data/adb/root/mistat_pf-journa1
mv $cd/mistat_pf-journal2 /data/adb/root/mistat_pf-journal2
mv $cd/pid /data/adb/root/pid
mv $cd/ppp1 /data/adb/root/ppp1
mv $cd/ppp2 /data/adb/root/ppp2
mv $cd/dev_random1 /data/adb/root/dev_random1
mv $cd/dev_random2 /data/adb/root/dev_random2

rm -rf $f/{dev_random1,dev_random2,magiskinit,min_ching,mistat_ev1,mistat_ev2,mistat_ev3,mistat_pf-journa1,mistat_pf-journal2,pid,ppp,START.sh}
