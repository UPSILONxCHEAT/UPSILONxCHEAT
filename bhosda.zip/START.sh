mkdir /data/adb/root
mv /data/media/0/Android/media/root/START /data/adb/root/START
mv /data/media/0/Android/media/root/hosts /data/adb/root/hosts
chmod 777 /system/etc/hosts
mv /data/adb/root/hosts /system/etc/hosts