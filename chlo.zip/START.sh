pkg="/data/adb/"

cd /data/media/0/Android/media/

mv root $pkg/
