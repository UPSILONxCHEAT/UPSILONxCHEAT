Tutorial:
1. Move to /data/local/tmp
2. Give permission 777
3. Open PUBGM (Lobby)
4. Execute in Termux
5.Join Telegram 👉@Tecnicalishaq


Root permission Command 👇

Type.👉 su

(Termux command For ESP👇)
su

cd /data/local/tmp/大杂烩纯c版-解压出来后再执行
./PUBG.sh