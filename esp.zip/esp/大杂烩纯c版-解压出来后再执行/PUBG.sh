cp lib/temp /data/tempp
cp lib/temppubg /data/tempp2
chmod 777 /data/tempp*
/data/tempp