var snow = require('res/snow.js');//雪花模块
importClass(java.io.InputStream)
importClass(java.net.ServerSocket)
importClass(java.net.Socket)
 function SocketServer() {
  
    // 监听指定的端口
    port = 55533;
    server = new ServerSocket(port);
    
    // server将一直等待连接的到来
    print("server将一直等待连接的到来");
    
   socket = server.accept();
    // 建立好连接后，从socket中获取输入流，并建立缓冲区进行读取
    while(true){//sleep(500)
    inputStream = socket.getInputStream();
    importClass('android.util.Base64');  
var bytes = Base64.decode(files.read('/storage/emulated/0/1A.Auto.js/雪花雷达透视/res/数组.txt'),Base64.NO_WRAP);  
   
    //sb = new StringBuilder();
    
   // while ((len = inputStream.read(bytes)) != -1) {
      //注意指定编码格式，发送方和接收方一定要统一，建议使用UTF-8
    
     inputStream.read(bytes)
     sb=snow.bTs(bytes)
     if(到字符(sb,"C")==""){break}
     
   // }
    toast(到字符(sb,"C"));}
    inputStream.close();
    socket.close();
    server.close();
  
}

SocketServer()

function 取文本左边(text,long){return text.slice(0,long)}
function 取文本右边(text,long){return text.slice(text.length-long,text.long)}
function 取文本中间(text,a,long){return text.slice(a-1,a-1+long)}
function 取中间文本(text,t1,t2){var a=text.indexOf(t1);var b=text.indexOf(t2);if (a==-1|b==-1){return ''};return text.slice(a+t1.length,b)}
function 取文本长度(text){return text.length}
function 寻找文本(text,t1,a){text=text+"哇";var result=text.indexOf(t1,a-1);if(result!=-1){return result+1};return -1}
function 到字符(text,cs1){var a=寻找文本(text,cs1);if(a>0){return 取文本左边(text,a-1)}else{return ""}}
