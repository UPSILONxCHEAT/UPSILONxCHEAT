importClass(android.graphics.PorterDuff);//绘制权限

fk()
sleep(999999)
function fk(){
 windowfk = floaty.rawWindow(
    <frame>
    <canvas id="board"/>
    </frame>)
    
    windowfk.setTouchable(false);windowfk.setSize(-1,-1);
   var paint = new Paint();paint.setStrokeWidth(3.0);//paint.setStyle(Paint.Style.STROKE)
  //  var paint2 = new Paint();paint2.setColor(colors.parseColor("#FFFFFF"));paint2.setTextSize(30);paint2.setStrokeWidth(4.0)
  //  var paint23 = new Paint();paint23.setColor(colors.parseColor("#FFFFFF"));paint23.setTextSize(30);paint23.setStrokeWidth(4.0)
    var paint22 = new Paint();paint22.setColor(colors.parseColor("#99FFFFFF"));paint22.setTextSize(35);paint22.setFakeBoldText(true);paint22.setStrokeWidth(0.8);paint22.setStyle(Paint.Style.STROKE)
//var paintabc = new Paint();paintabc.setStrokeWidth(3.0);paintabc.setColor(colors.parseColor("#FFFFFF"))
//var paintcolor = new Paint();paintcolor.setColor(colors.parseColor("#DC143C"));paintcolor.setStrokeWidth(4.0)
//var paintcolor2 = new Paint();paintcolor2.setColor(colors.parseColor("#9900FF00"));paintcolor2.setStrokeWidth(8.0)

windowfk.board.on("draw", function(canvas){
    canvas.drawColor(0, PorterDuff.Mode.CLEAR);
 var x=300;var y=300;var w=465;var bj=w*30/465;var ys=0;var xs=0
 
 paint22.setColor(colors.parseColor("#99DC143C"));paint22.setStrokeWidth(3)
canvas.drawRect(x,y,x+w,y+w*2,paint22)
 canvas.drawCircle(x+w/2,y+w,100,paint22);
})}