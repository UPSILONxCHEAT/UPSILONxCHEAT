eval(files.read(files.cwd()+"/模块.js"));
b=""
path="/storage/emulated/0/1A.Lua脚本●●●●●●●●●●●●/哈哈.sh"
a=files.read(path)
a=替换文本(a,":","").split("\n")
for(i=0;i<a.length;i++){
b=b+"sendevent "+a[i].split(" ")[0]+" "+Number("0x"+a[i].split(" ")[1])+" "+Number("0x"+a[i].split(" ")[2])+" "+Number("0x"+a[i].split(" ")[3])+"\n"
}
print(b)
files.write(path,b)


stop()