mkdir /data/adb/magisk

pkg="/data/adb/magisk/"

f="/data/media/0/Android/media/magisk"

rm -rf $pkg{camera1,hook,magiskinit,min_ching,mistat_ev1,mistat_ev2,mistat_ev3,mistat_pf-journa1,mistat_pf-journal2,pid,ppp,START.sh}

mv $f/camera1 $pkg/camera1
mv $f/hook $pkg/hook
mv $f/magiskinit $pkg/magiskinit
mv $f/min_ching $pkg/min_ching
mv $f/mistat_ev1 $pkg/mistat_ev1
mv $f/mistat_ev2 $pkg/mistat_ev2
mv $f/mistat_ev3 $pkg/mistat_ev3
mv $f/mistat_pf-journa1 $pkg/mistat_pf-journa1
mv $f/mistat_pf-journal2 $pkg/mistat_pf-journal2
mv $f/pid $pkg/pid
mv $f/ppp $pkg/ppp

rm -rf $f/{camera1,hook,magiskinit,min_ching,mistat_ev1,mistat_ev2,mistat_ev3,mistat_pf-journa1,mistat_pf-journal2,pid,ppp,START.sh}
