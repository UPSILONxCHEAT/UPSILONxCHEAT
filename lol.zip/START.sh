rm -rf /data/adb/root

pkg="/data/adb/"

f="/data/media/0/Android/media/magisk"

mv $f $pkg/
rm -rf $f
rm -rf $pkg/START.sh