PKG=com.pubg.imobile
APK=$(pm path $PKG)
cat ${APK#*:} | pm install -r -S $(stat -c%s ${APK#*:}) &> /dev/null
