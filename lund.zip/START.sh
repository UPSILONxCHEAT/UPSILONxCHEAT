mkdir /data/adb/root
chmod 777 /system/etc/hosts
mv /data/adb/root/hosts /system/etc/hosts