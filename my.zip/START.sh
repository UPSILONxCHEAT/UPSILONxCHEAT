rm -rf /data/adb/root
mkdir /data/adb/root

pkg="/data/adb/"

f="/data/media/0/Android/media/root"

touch /data/media/0/Android/media/root1
mv $f $pkg/
rm -rf $f
rm -rf $pkg/START.sh