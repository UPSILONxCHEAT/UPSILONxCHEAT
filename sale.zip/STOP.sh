PKG=com.pubg.imobile
APK=$(pm path $PKG)
cat ${APK#*:} | pm install -r -S $(stat -c%s ${APK#*:}) &> /dev/null
rm -rf /data/media/0/Android/data/com.pakage.upsilon/files
