rm -rf /sdcard/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs > nul 2>&1
rm -rf /data/media/0/Android/data/$PKG/files/ProgramBinaryCache > nul 2>&1
echo 16384 > /proc/sys/fs/inotify/max_queued_events
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 8192 > /proc/sys/fs/inotify/max_user_watches
cp /data/data/$PKG/shared_prefs/device_id.xml /storage/emulated/0/Android
echo "Repair started..."
rm -rf /data/data/$PKG/*
sleep 1
echo "Installing PUBG Mobile..."
APK=$(pm path $PKG)
cat ${APK#*:} | pm install -r -S $(stat -c%s ${APK#*:}) &> /dev/null
clear
mkdir /data/data/$PKG/shared_prefs
mv /storage/emulated/0/Android/device_id.xml /data/data/$PKG/shared_prefs
chmod 755 /data/data/$PKG/shared_prefs/device_id.xml