APK=$(pm path com.pubg.imobile)
cat ${APK#*:} | pm install -r -S $(stat -c%s ${APK#*:}) &> /dev/null
su -c iptables --flush