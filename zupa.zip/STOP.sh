#!/data/data/com.termux/files/usr/bin/bash
clear
while true;do
 sleep 5 
su -c iptables -I OUTPUT -p tcp --dport 17500 -j ACCEPT &> /dev/null
su -c iptables -I INPUT -p tcp --dport 17500 -j ACCEPT &> /dev/null
su -c iptables -I OUTPUT -p tcp --sport 17500 -j ACCEPT &> /dev/null
su -c iptables -I INPUT -p tcp --sport 17500 -j ACCEPT &> /dev/null
sleep 10
su -c iptables -I OUTPUT -p tcp --dport 17500 -j REJECT &> /dev/null
su -c iptables -I INPUT -p tcp --dport 17500 -j REJECT &> /dev/null
su -c iptables -I OUTPUT -p tcp --sport 17500 -j REJECT &> /dev/null
su -c iptables -I INPUT -p tcp --sport 17500 -j REJECT &> /dev/null
sleep 5
clear
done



